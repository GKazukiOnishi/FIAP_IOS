//
//  ViewController.swift
//  Pontos no Mapa
//
//  Created by Usuário Convidado on 21/10/24.
//

import UIKit
import MapKit

class ViewController: UIViewController {

    @IBOutlet weak var mapa: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let annotation = MKPointAnnotation()
        annotation.coordinate = CLLocationCoordinate2D(latitude: 41.890251, longitude: 12.492373)
        annotation.title = "O Coliseu"
        annotation.subtitle = "A casa dos Gladiadores"
        mapa.addAnnotation(annotation)
        
        let region = MKCoordinateRegion(center: annotation.coordinate, latitudinalMeters: 300, longitudinalMeters: 300)
        mapa.setRegion(region, animated: true)
    }

}

