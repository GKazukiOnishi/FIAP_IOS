//
//  ViewController.swift
//  Buscar Endereço
//
//  Created by Usuário Convidado on 21/10/24.
//

import UIKit
import MapKit
import CoreLocation


class ViewController: UIViewController {

    @IBOutlet weak var textEndereco: UITextField!
    @IBOutlet weak var buttonEndereco: UIButton!
    @IBOutlet weak var mapa: MKMapView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buscar(_ sender: Any) {
        LocalizarEndereco()
    }
    
    func LocalizarEndereco(){
        let geoCoder = CLGeocoder()
        geoCoder.geocodeAddressString(textEndereco.text!) { placemarks, error in
            guard let placemarks = placemarks, let location = placemarks.first?.location
            else{
                print("Não encontrou o endereço")
                return
            }
            print(location)
        }
    }
    
}

