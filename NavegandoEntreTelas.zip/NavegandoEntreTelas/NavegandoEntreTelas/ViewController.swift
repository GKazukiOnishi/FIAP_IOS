//
//  ViewController.swift
//  NavegandoEntreTelas
//
//  Created by Usuário Convidado on 06/05/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func fechar(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
}

