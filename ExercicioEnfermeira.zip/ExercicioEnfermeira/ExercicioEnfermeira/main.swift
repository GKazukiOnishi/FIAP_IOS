//
//  main.swift
//  ExercicioEnfermeira
//
//  Created by Usuário Convidado on 18/03/24.
//

import Foundation

print("Hello, World!")


var enfermeiraTst1:Enfermeira = Enfermeira(nome: "Ana", salario: 4500.99, emTreinamento: false, idade: 35)
print(enfermeiraTst1)

enfermeiraTst1.exibir()

print(enfermeiraTst1.getIdade())
print(enfermeiraTst1.isTreinamento())
print(enfermeiraTst1.prepararBanho(temperaturaAgua: 35, paciente: "José"))
print(enfermeiraTst1.verificaFebrePaciente(temperaturaPaciente: 39))
