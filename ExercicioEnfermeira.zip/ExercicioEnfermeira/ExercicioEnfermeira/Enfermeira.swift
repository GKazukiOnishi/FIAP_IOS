//
//  Enfermeira.swift
//  ExercicioEnfermeira
//
//  Created by Usuário Convidado on 18/03/24.
//

import Cocoa

class Enfermeira: NSObject {
    
    var nome:String
    var salario:Float
    var emTreinamento:Bool
    var idade:Int
    
    init(nome: String, salario: Float, emTreinamento: Bool, idade: Int) {
        self.nome = nome
        self.salario = salario
        self.emTreinamento = emTreinamento
        self.idade = idade
    }
    
    func toString() -> String {
        let salarioFormatado = String(format: "%0.2f", self.salario)
        return "Enfermeira \(self.nome) com \(self.idade) anos. Salário R$ \(salarioFormatado). Em treinamento? \(emTreinamento ? "Sim": "Não")"
    }
    
    func exibir() {
        print(toString())
    }
    
    func isTreinamento() -> Bool {
        return self.emTreinamento
    }
    
    func getIdade() -> Int {
        return self.idade
    }
    
    func verificaFebrePaciente(temperaturaPaciente:Float) -> Bool {
        return temperaturaPaciente >= 37
    }
    
    func prepararBanho(temperaturaAgua:Float, paciente:String) -> String {
        return "Banho sendo preparado para o paciente \(paciente) na temperatura de \(temperaturaAgua) graus celsius"
    }
    
}
