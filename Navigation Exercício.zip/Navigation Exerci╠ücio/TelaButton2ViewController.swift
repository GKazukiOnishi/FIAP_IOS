//
//  TelaButton2ViewController.swift
//  Navigation Exercício
//
//  Created by Usuário Convidado on 06/05/24.
//

import UIKit

class TelaButton2ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func fechar(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let t = segue.destination
        
    }

}
