//
//  ViewController.swift
//  Core Data Exemplo
//
//  Created by Usuário Convidado on 14/10/24.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    @IBOutlet weak var txtNome: UITextField!
    @IBOutlet weak var txtTelefone: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func salvar(_ sender: Any) {
        save(name: txtNome.text!, tele: txtTelefone.text!, emai: txtTelefone.text!)
        self.navigationController?.popViewController(animated: true)
    }
    
    func save(name:String, tele:String, emai:String){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedContext = appDelegate.persistentContainer.viewContext
        let entidade = NSEntityDescription.entity(forEntityName: "Pessoa", in: managedContext)!
        
        //inicio do processo de gravação
        let pessoa = NSManagedObject(entity: entidade, insertInto: managedContext)
        pessoa.setValue(name, forKey: "nome")
        pessoa.setValue(tele, forKey: "telefone")
        pessoa.setValue(emai, forKey: "email")
        
        do{
            try managedContext.save()
        }catch let error as NSError{
            print("Não foi possível salvar \(error) \(error.userInfo)")
        }
    }
    
}

