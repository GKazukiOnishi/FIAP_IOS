//
//  Medico.swift
//  GABRIELKAZUKI_RM87182__Mod5
//
//  Created by Usuário Convidado on 22/04/24.
//

import Foundation

class Medico {
    
    var nome:String
    var salario:Float
    var especialidade:String
    var crm:Int
    var disponivel:Bool
    
    init() {
        self.nome = ""
        self.salario = 0
        self.especialidade = ""
        self.crm = 0
        self.disponivel = true
    }
    
    func verificarDisponibilidade(especialidadeDesejada:String) -> Bool {
        if (self.especialidade == especialidadeDesejada && self.disponivel) {
            return true
        } else {
            return false
        }
    }
    
    func apresentarMedico() -> String {
        return "\(self.nome) - CRM \(self.crm) - Especialidade: \(self.especialidade) - Disponibilidade: \(self.disponivel ? "Disponível" : "Ocupado") - Salário: \(self.salario)"
    }
    
}
