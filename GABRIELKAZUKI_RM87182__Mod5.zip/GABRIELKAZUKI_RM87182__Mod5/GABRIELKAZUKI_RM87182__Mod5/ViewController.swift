//
//  ViewController.swift
//  GABRIELKAZUKI_RM87182__Mod5
//
//  Created by Usuário Convidado on 22/04/24.
//

import UIKit

class ViewController: UIViewController {
    
    //Nome: Gabriel Kazuki Onishi - RM 87182 - Mod 5
    
    @IBOutlet weak var txtNome: UITextField!
    @IBOutlet weak var txtCRM: UITextField!
    @IBOutlet weak var txtEspecialidade: UITextField!
    @IBOutlet weak var txtSalario: UITextField!
    @IBOutlet weak var txtEspecialidadeDesejada: UITextField!
    @IBOutlet weak var switchDisponivel: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func getMedico() -> Medico {
        var medico = Medico()
        medico.nome = txtNome.text!
        medico.crm = Int(txtCRM.text!)!
        medico.especialidade = txtEspecialidade.text!
        medico.salario = Float(txtSalario.text!)!
        medico.disponivel = switchDisponivel.isOn
        
        return medico
    }
    
    @IBAction func exibirDadosClicked(_ sender: Any) {
        var medico = getMedico()
        var msg = medico.apresentarMedico()
        
        let alerta = UIAlertController(title: "Dados do Médico", message: msg, preferredStyle: UIAlertController.Style.alert)
        
        alerta.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        
        present(alerta, animated: true, completion: nil)
    }
    
    @IBAction func verificarDisponibilidadeClicked(_ sender: Any) {
        var medico = getMedico()
        var disponivel = medico.verificarDisponibilidade(especialidadeDesejada: txtEspecialidadeDesejada.text!)
        var msg = ""
        
        if (disponivel) {
            msg = "O médico está disponível"
        } else {
            msg = "O médico não está disponível"
        }
        
        let alerta = UIAlertController(title: "Disponibilidade", message: msg, preferredStyle: UIAlertController.Style.alert)
        
        alerta.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        
        present(alerta, animated: true, completion: nil)
    }
    
}

