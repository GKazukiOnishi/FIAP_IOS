//
//  ViewController.swift
//  Exemplo MVC Swift
//
//  Created by Usuário Convidado on 25/03/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtAtleta: UITextField!
    @IBOutlet weak var txtPeso: UITextField!
    @IBOutlet weak var txtAltura: UITextField!
    @IBOutlet weak var txtImc: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func calcular(_ sender: Any) {
        var pessoa = Pessoa(nome: txtAtleta.text, peso: Float(txtPeso.text!), altura: Float(txtAltura.text!))
        txtImc.text = pessoa.getIMCFormatado()
    }
    
}

