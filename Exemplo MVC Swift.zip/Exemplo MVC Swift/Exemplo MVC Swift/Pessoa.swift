//
//  Pessoa.swift
//  Exemplo MVC Swift
//
//  Created by Usuário Convidado on 25/03/24.
//

import Foundation

class Pessoa {
    
    var nome:String!
    var peso:Float!
    var altura:Float!
    var imc:Float!
    
    init(nome: String!, peso: Float!, altura: Float!) {
        self.nome = nome
        self.peso = peso
        self.altura = altura
        calcularIMC()
    }
    
    func calcularIMC() {
        if peso == 0 || altura == 0 {
            imc = 0
        } else {
            imc = peso / (altura * altura)
        }
    }
    
    func getIMCFormatado() -> String {
        return String(format: "%.2f", self.imc)
    }
    
}
