//
//  ViewController.swift
//  Exemplo 1 - REST IOS Nutella
//
//  Created by Usuário Convidado on 09/09/24.
//

import UIKit

// Struct declarado aqui em cima
var comic:Comic!=nil

class ViewController: UIViewController {
    
    @IBOutlet weak var lblId: UILabel!
    @IBOutlet weak var lblData: UILabel!
    @IBOutlet weak var lblTitulo: UILabel!
    @IBOutlet weak var imgFoto: UIImageView!
    
    var comicNum:Int = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func next(_ sender: Any) {
        comicNum = comicNum + 1
        exibir(sender)
    }
    
    
    @IBAction func previus(_ sender: Any) {
        comicNum = comicNum - 1
        exibir(sender)
    }
    
    @IBAction func exibir(_ sender: Any) {
        let jsonURLString = "https://xkcd.com/\(comicNum)/info.0.json"
        let url = URL(string: jsonURLString)
        
        URLSession.shared.dataTask(with: url!) { data, response, error in
            guard let data = data else { return }
            
            do {
                comic = try JSONDecoder().decode(Comic.self, from: data)
                print(comic.title)
                
                DispatchQueue.main.sync {
                    self.lblTitulo.text = comic.title
                    self.lblId.text = String(comic.num)
                    self.lblData.text = comic.day + "/" + comic.month + "/" + comic.year
                    self.imgFoto.image = self.carregarImagem(urlImagem: comic.img)
                }
            } catch let jsonError {
                print("Erro de serializacao no Json", jsonError)
            }
        }
        .resume()
    }
    
    func carregarImagem(urlImagem:String) -> UIImage? {
        guard let url = URL(string: urlImagem)
        else {
            print("Nao foi possivel criar a URL")
            return nil
        }
        
        var image:UIImage?=nil
        do {
            let data = try Data(contentsOf: url)
            
            image = UIImage(data: data)
        } catch {
            print(error.localizedDescription)
        }
        
        return image
    }

}

