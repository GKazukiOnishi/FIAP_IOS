//
//  ViewController.swift
//  TableDeJogos
//
//  Created by Usuário Convidado on 19/08/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var nomesJogos = ["Horizon Zero Dawn", "Uncharted 4"]
    var urlImgJogos = ["hor", "unc"]
    var studiosJogos = ["Guerrila", "Naughty Dog"]
    var notasJogos = [5, 3]
    var rowSelecionada: Int = 0
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
    }


    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nomesJogos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celula = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
        
        celula.textLabel?.text = nomesJogos[indexPath.row]
        celula.imageView?.image = UIImage(named: urlImgJogos[indexPath.row])
        celula.detailTextLabel?.text = studiosJogos[indexPath.row]
        celula.accessoryType = .detailButton //UITableViewCell.AccessoryType.detailButton
        
        return celula
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Jogo clicado: \(nomesJogos[indexPath.row])")
        
        rowSelecionada = indexPath.row
        performSegue(withIdentifier: "tableViewParaDetalheJogoSegue", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "tableViewParaDetalheJogoSegue" {
            let t = segue.destination as! DetalheJogoViewController
            t.nomeJogo = nomesJogos[rowSelecionada]
        }
    }
    
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        let alerta = UIAlertController(
            title: "Nota do Jogo",
            message: "\(nomesJogos[indexPath.row]) - \(notasJogos[indexPath.row])",
            preferredStyle: UIAlertController.Style.alert
        )
        
        alerta.addAction(UIAlertAction(title: "Fechar", style: UIAlertAction.Style.default))
        
        present(alerta, animated: true)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == .delete) {
            nomesJogos.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }

}

