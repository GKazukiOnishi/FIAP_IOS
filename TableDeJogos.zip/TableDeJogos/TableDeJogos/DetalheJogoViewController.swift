//
//  DetalheJogoViewController.swift
//  TableDeJogos
//
//  Created by Usuário Convidado on 19/08/24.
//

import UIKit

class DetalheJogoViewController: UIViewController {

    var nomeJogo: String = ""
    @IBOutlet weak var lblNomeJogo: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        lblNomeJogo.text = nomeJogo
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
