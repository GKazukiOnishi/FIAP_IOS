//
//  AlimentoLiquido.swift
//  ExemploClasse
//
//  Created by Usuário Convidado on 11/03/24.
//

import Foundation

protocol AlimentoLiquido {
    
    func beberIsotonico()
    
}
