//
//  Atleta.swift
//  ExemploClasse
//
//  Created by Usuário Convidado on 04/03/24.
//

import Cocoa

class Atleta: NSObject {
    
    var nome:String
    var idade:Int
    
    override init() {
        self.nome = ""
        self.idade = 0
    }
    
    init(nome:String, idade:Int) {
        self.nome = nome
        self.idade = idade
    }
    
    deinit {
        print("Destruindo \(self.nome)")
    }
    
    // Criando sub-rotina (sem retorno)
    func calculaIMC(peso:Float, altura:Float) {
        let imc = peso / (altura * altura)
        let formatado = String(format: "%0.2f", imc)
        print("O IMC de \(nome) é \(formatado)")
    }
    
    // Criando uma function (com retorno)
    func calculaIMCFunc(peso:Float, altura:Float) -> Float {
        return peso / pow(altura, 2)
    }
    
    func exibirAtleta() -> String {
        return "Atleta é \(self.nome)"
    }
    
    class func alerta() -> String {
        return "A competição irá iniciar em breve"
    }
    
    class func alerta(tempoEmMinutos:Int) -> String {
        return "A competição irá iniciar em \(tempoEmMinutos) minutos"
    }
}
