//
//  AlimentoLiquidoSolido.swift
//  ExemploClasse
//
//  Created by Usuário Convidado on 11/03/24.
//

import Foundation

protocol AlimentoLiquidoSolido: AlimentoLiquido, AlimentoSolido {
    
    func ingerirAlimentoPastoso()
    
}
