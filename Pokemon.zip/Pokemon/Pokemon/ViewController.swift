//
//  ViewController.swift
//  Pokemon
//
//  Created by Usuário Convidado on 23/09/24.
//

import UIKit

// Struct declarado aqui em cima
var pokemonResponse:PokemonResponse!=nil

class ViewController: UIViewController {

    @IBOutlet weak var txtNomePokemon: UITextField!
    
    @IBOutlet weak var lblNomePokemon: UILabel!
    @IBOutlet weak var lblIdPokemon: UILabel!
    @IBOutlet weak var imgPokemon: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func exibirPokemon(_ sender: Any) {
        let nomeInformado = txtNomePokemon.text!
        let jsonURLString = "https://pokeapi.co/api/v2/pokemon/\(nomeInformado)"
        let url = URL(string: jsonURLString)
        
        URLSession.shared.dataTask(with: url!) { data, response, error in
            guard let data = data else { return }
            
            do {
                pokemonResponse = try JSONDecoder().decode(PokemonResponse.self, from: data)
                
                DispatchQueue.main.sync {
                    self.lblNomePokemon.text = pokemonResponse.name
                    self.lblIdPokemon.text = String(pokemonResponse.id)
                    self.imgPokemon.image = self.carregarImagem(urlImagem: pokemonResponse.sprites.front_default)
                }
            } catch let jsonError {
                print("Erro de serializacao no Json", jsonError)
            }
        }
        .resume()
    }
    
    func carregarImagem(urlImagem:String) -> UIImage? {
        guard let url = URL(string: urlImagem)
        else {
            print("Nao foi possivel criar a URL")
            return nil
        }
        
        var image:UIImage?=nil
        do {
            let data = try Data(contentsOf: url)
            
            image = UIImage(data: data)
        } catch {
            print(error.localizedDescription)
        }
        
        return image
    }
    
}

