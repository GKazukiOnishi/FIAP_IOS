//
//  EstruturaPokemonAPI.swift
//  Pokemon
//
//  Created by Usuário Convidado on 23/09/24.
//

import Foundation

struct PokemonResponse:Decodable {
    var id:Int
    var name:String
    var sprites:PokemonSpriteResponse
}

struct PokemonSpriteResponse:Decodable {
    var front_default:String
}
