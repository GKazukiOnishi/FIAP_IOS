//
//  ViewController.swift
//  GABRIEL_RM87182__Mod3
//
//  Created by Usuário Convidado on 04/11/24.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var txtNome: UITextField!
    @IBOutlet weak var txtTime: UITextField!
    @IBOutlet weak var txtIdade: UITextField!
    @IBOutlet weak var txtTipo: UITextField!
    
    var jogadorVindoDaTable:NSManagedObject?=nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        if (jogadorVindoDaTable != nil) {
            txtNome.text = jogadorVindoDaTable?.value(forKey: "nome") as? String
            txtTime.text = jogadorVindoDaTable?.value(forKey: "time") as? String
            txtIdade.text = jogadorVindoDaTable?.value(forKey: "idadeString") as? String
            txtTipo.text = jogadorVindoDaTable?.value(forKey: "tipo") as? String
        }
    }
    
    @IBAction func salvar(_ sender: Any) {
        salvarNoCore(nome: txtNome.text!, time: txtTime.text!, idade: txtIdade.text!, tipo: txtTipo.text!)
        self.navigationController?.popViewController(animated: true)
    }
    
    func salvarNoCore(nome:String, time:String, idade:String, tipo:String){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedContext = appDelegate.persistentContainer.viewContext
        let entidade = NSEntityDescription.entity(forEntityName: "Jogador", in: managedContext)!
        
        print(idade)
        
        if jogadorVindoDaTable == nil {
            //inicio do processo de gravação
            let jogador = NSManagedObject(entity: entidade, insertInto: managedContext)
            jogador.setValue(nome, forKey: "nome")
            jogador.setValue(time, forKey: "time")
            jogador.setValue(idade, forKey: "idadeString")
            jogador.setValue(tipo, forKey: "tipo")
        } else {
            let objectUpdate = jogadorVindoDaTable
            objectUpdate?.setValue(nome, forKey: "nome")
            objectUpdate?.setValue(time, forKey: "time")
            objectUpdate?.setValue(idade, forKey: "idadeString")
            objectUpdate?.setValue(tipo, forKey: "tipo")
        }
        
        do{
            try managedContext.save()
        }catch let error as NSError{
            print("Não foi possível salvar \(error) \(error.userInfo)")
        }
    }

}

