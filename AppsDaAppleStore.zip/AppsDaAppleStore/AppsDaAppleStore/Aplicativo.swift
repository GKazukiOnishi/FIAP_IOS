//
//  Aplicativo.swift
//  AppsDaAppleStore
//
//  Created by Usuário Convidado on 07/10/24.
//

import UIKit

class Aplicativo: NSObject {

    var nome: String = ""
    var imageSTR: String = ""
    var imagem: UIImage? = nil
    var categoria: String = ""
    
}
